let options = [];
const optionLabels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';
const MODEL = 'deepseek-chat';

const elements = {
  optionInput: document.getElementById('optionInput'),
  voiceBtn: document.getElementById('voiceBtn'),
  optionsList: document.getElementById('optionsList'),
  askBtn: document.getElementById('askBtn'),
  result: document.getElementById('result'),
  loading: document.getElementById('loading'),
  error: document.getElementById('error'),
  settingsLink: document.getElementById('settingsLink'),
  recommendText: document.getElementById('recommendText'),
  reasonText: document.getElementById('reasonText'),
  warningText: document.getElementById('warningText')
};

function init() {
  elements.optionInput.addEventListener('keypress', handleKeyPress);
  elements.voiceBtn.addEventListener('click', toggleVoiceInput);
  elements.askBtn.addEventListener('click', handleAskAI);
  elements.settingsLink.addEventListener('click', openSettings);
  
}

function handleKeyPress(e) {
  if (e.key === 'Enter') {
    const text = elements.optionInput.value.trim();
    if (text) {
      addOption(text);
      elements.optionInput.value = '';
    }
  }
}

function addOption(text) {
  if (!text.trim()) return;
  const label = optionLabels[options.length] || (options.length + 1).toString();
  options.push({ label, text });
  renderOptions();
}

function deleteOption(index) {
  options.splice(index, 1);
  renderOptions();
}

function renderOptions() {
  if (options.length === 0) {
    elements.optionsList.innerHTML = '<div class="empty-state">还没有选项，添加一个试试？</div>';
    return;
  }

  elements.optionsList.innerHTML = options.map((opt, i) => `
    <div class="option-item">
      <span class="option-label">${opt.label}</span>
      <span class="option-text">${escapeHtml(opt.text)}</span>
      <button class="delete-btn" data-index="${i}">×</button>
    </div>
  `).join('');

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', () => deleteOption(parseInt(btn.dataset.index)));
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

let recognition = null;
let isRecording = false;
let initialText = '';

function toggleVoiceInput() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    showError('您的浏览器不支持语音识别功能');
    return;
  }

  if (!recognition) {
    recognition = new SpeechRecognition();
    recognition.lang = 'zh-CN';
    recognition.interimResults = true;
    recognition.continuous = false;

    recognition.onstart = () => {
      isRecording = true;
      initialText = elements.optionInput.value;
      elements.voiceBtn.classList.add('recording');
      hideError();
    };

    recognition.onend = () => {
      isRecording = false;
      elements.voiceBtn.classList.remove('recording');
    };

    recognition.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map(result => result[0].transcript)
        .join('');
      
      const newText = initialText ? (initialText + ' ' + transcript) : transcript;
      elements.optionInput.value = newText;
      elements.optionInput.focus();
    };

    recognition.onerror = (event) => {
      console.error('Speech recognition error', event.error);
      if (event.error === 'not-allowed') {
        showError('请允许麦克风权限');
      } else if (event.error !== 'no-speech') {
        showError('语音识别错误: ' + event.error);
      }
      isRecording = false;
      elements.voiceBtn.classList.remove('recording');
    };
  }

  if (isRecording) {
    recognition.stop();
  } else {
    recognition.start();
  }
}

function buildPrompt() {
  const optionsText = options.map(o => `${o.label}. ${o.text}`).join('\n');
  return `我需要你帮我做一个选择。以下是选项：
${optionsText}

请用轻松幽默的语气回复，格式如下：
推荐：[选择哪个]
理由：[简短有趣的解释]
风险提醒：[可能的后悔点]
`;
}

function parseResult(text) {
  const recommendMatch = text.match(/推荐[：:]\s*([^\n]+)/);
  const reasonMatch = text.match(/理由[：:]\s*([\s\S]*?)(?=风险|$)/);
  const warningMatch = text.match(/风险提醒[：:]\s*([\s\S]*)/);

  return {
    recommend: recommendMatch ? recommendMatch[1].trim() : '看缘分吧',
    reason: reasonMatch ? reasonMatch[1].trim() : '选择本身就是意义',
    warning: warningMatch ? warningMatch[1].trim() : '无论如何都可能后悔，但这才是人生嘛'
  };
}

async function handleAskAI() {
  hideError();

  if (options.length < 2) {
    showError('至少需要 2 个选项才能做选择哦~');
    return;
  }

  const { apiKey } = await chrome.storage.local.get('apiKey');
  if (!apiKey) {
    showError('请先设置 API Key，点击下方"API 设置"');
    return;
  }

  elements.result.classList.add('hidden');
  elements.loading.classList.remove('hidden');
  elements.askBtn.disabled = true;

  try {
    const prompt = buildPrompt();
    const response = await fetch(DEEPSEEK_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || `API 请求失败: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    const result = parseResult(content);

    elements.recommendText.textContent = result.recommend;
    elements.reasonText.textContent = result.reason;
    elements.warningText.textContent = result.warning;

    elements.loading.classList.add('hidden');
    elements.result.classList.remove('hidden');
  } catch (err) {
    elements.loading.classList.add('hidden');
    showError(err.message || '请求失败，请检查网络或 API Key');
  } finally {
    elements.askBtn.disabled = false;
  }
}

function showError(message) {
  elements.error.textContent = message;
  elements.error.classList.remove('hidden');
}

function hideError() {
  elements.error.classList.add('hidden');
}

function openSettings(e) {
  e.preventDefault();
  if (chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    window.open('options.html', '_blank');
  }
}

document.addEventListener('DOMContentLoaded', init);

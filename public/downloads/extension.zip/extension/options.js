document.addEventListener('DOMContentLoaded', async () => {
  const apiKeyInput = document.getElementById('apiKey');
  const saveBtn = document.getElementById('saveBtn');
  const status = document.getElementById('status');

  const { apiKey } = await chrome.storage.local.get('apiKey');
  if (apiKey) {
    apiKeyInput.value = apiKey;
  }

  saveBtn.addEventListener('click', async () => {
    const apiKey = apiKeyInput.value.trim();
    
    if (!apiKey) {
      status.textContent = '请输入 API Key';
      status.className = 'error';
      return;
    }

    if (!apiKey.startsWith('sk-')) {
      status.textContent = 'API Key 格式不正确，应以 sk- 开头';
      status.className = 'error';
      return;
    }

    try {
      await chrome.storage.local.set({ apiKey });
      status.textContent = '✅ 已保存！';
      status.className = 'success';
    } catch (err) {
      status.textContent = '保存失败：' + err.message;
      status.className = 'error';
    }
  });
});
